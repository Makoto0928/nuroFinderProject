# nuroFinderProject
Find apartments installed "NURO HIKARI for mansion" in Tokyo 23-ku.  
This program is using Selenium and Google GeoCoding.  
Crawling address and searching Lat&Lng by crawled address.  
Finally, it is output in the form of a csv file (Address, Lat, Lng).
